# IT 3203 Milestone 1 — Cybersecurity Website

## Contents
Six HTML pages, one CSS stylesheet, and one original SVG image.

## Preview
Open `index.html` in a browser. Navigate using the shared menu.

## Publish on GitHub Pages
1. Create a new public GitHub repository (for example, `it3203-milestone1`).
2. Upload all files and the `assets` folder to the repository root (not the outer ZIP folder).
3. In repository Settings > Pages, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, and Save.
4. Wait for GitHub Pages deployment and open the published URL.
5. Verify every link and image.

## Validation
Validate each HTML file at https://validator.w3.org/ (file upload or live URL). Correct any reported errors. This project has not been run through the online validator or deployed automatically.

## Checklist
- Six pages and consistent navigation
- Headings, lists, image, tables
- Single CSS file; element, class, and ID selectors
- CSS Grid and Flexbox; hover, margins, padding, borders, colors, fonts
- Source comments and course footer
- GitHub Pages publication and W3C validation remain to be completed by student

Review all content and personalize the About page before submission. Your course requires understanding and cleaning any generated code.
